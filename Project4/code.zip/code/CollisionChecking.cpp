///////////////////////////////////////
// RBE 550
// Project 4
// Authors: FILL ME OUT!!
//////////////////////////////////////

#include "CollisionChecking.h"

// TODO: Copy your implementation from previous projects

bool isValidPoint(double x, double y, const std::vector<Rectangle> &obstacles)
{
    return false;
}

bool isValidCircle(double x, double y, double radius, const std::vector<Rectangle> &obstacles)
{
    return false;
}

bool isValidSquare(double x, double y, double theta, double sideLength, const std::vector<Rectangle> &obstacles)
{
    return false;
}
