///////////////////////////////////////
// RBE 550
// Project 4
// Authors: FILL ME OUT!!
//////////////////////////////////////

#ifndef RGRRT_H
#define RGRRT_H

namespace ompl
{
    namespace control
    {
        // TODO: Implement RGRRT as described

        // class RGRRT : public base::Planner
        // {
        // };

    }  // namespace control 
}  // namespace ompl

#endif
